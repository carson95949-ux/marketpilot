# MarketPilot V2.9.2 — Live Market Feed Fix

- Added `/api/live`, an independent fresh-data endpoint for BTC spot and the current Polymarket BTC 5-minute order book.
- UP/DOWN displayed asks no longer depend only on the strategy database snapshot.
- The browser polls the live display feed about every 900 ms with cache disabled.
- Coinbase browser WebSocket remains active for fast chart ticks, with the server BTC ticker as a fallback.
- Added `LIVE MARKET`, `STALE MARKET`, and `RECONNECTING MARKET` status states.
- A stale strategy snapshot can no longer overwrite a newly rolled 5-minute market in the UI.
- `/api/state` and `/api/live` explicitly disable HTTP caching.
- Strategy decisions still come from `bot.py`; the new feed only fixes freshness of displayed market data.
- Added Polymarket's public market WebSocket (`wss://ws-subscriptions-clob.polymarket.com/ws/market`) for real-time order-book/best-ask updates.
- The REST live endpoint now acts as market discovery + fallback; the WebSocket is the primary visible quote stream once connected.
