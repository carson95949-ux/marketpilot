# Render deploy fix (V2.9.3)

## What changed
- Python is pinned to 3.12.11. Render's current default for newly created Python services is newer and can cause dependency incompatibilities.
- `render.yaml` remains the production setup: paid Starter + persistent `/var/data` disk.
- `render-free.yaml` is included for free testing. It intentionally has no disk because Render Free web services do not support persistent disks.

## Easiest free test deploy
Create a Render Web Service manually from the GitHub repo:
- Runtime: Python 3
- Build command: `pip install -r requirements.txt`
- Start command: `bash start_production.sh`
- Health check path: `/health`
- Environment variable: `PYTHON_VERSION=3.12.11`
- Environment variable: `MARKETPILOT_DATA_DIR=/tmp/marketpilot-data`
- Choose the Free compute plan.

Free testing warning: SQLite accounts/trades can reset when the free service restarts, sleeps, or redeploys.

## Production deploy
Use `render.yaml` as the Blueprint. It uses a paid Starter service and a persistent disk at `/var/data`.

## If it still fails
Open Render -> your service -> Logs and copy the final 20-30 lines of the failed deploy. The first red Python traceback or `ERROR` line is the useful part.
